import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/vpn_provider.dart';
import '../models/theme_model.dart';
import '../utils/scanlines_painter.dart';
import '../widgets/connect_button.dart';
import '../widgets/server_list.dart';
import '../widgets/sidebar_drawer.dart';
import '../widgets/theme_picker.dart';
import '../widgets/traffic_counter.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  bool _ruWarningShown = false;
  bool _welcomeShown = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkRuWarning();
    });
  }

  void _checkRuWarning() {
    final settings = ref.read(settingsProvider);
    if (!settings.suppressRuWarning && !_ruWarningShown) {
      _ruWarningShown = true;
      _showRuWarning();
    }
  }

  void _showRuWarning() {
    final settings = ref.read(settingsProvider);
    final theme = settings.theme;
    final primary = theme.primary;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: theme.background,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: Colors.red.withOpacity(0.7), width: 2),
        ),
        title: Row(
          children: [
            const Icon(Icons.warning_amber_rounded, color: Colors.red, size: 28),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                '⚠️ ВНИМАНИЕ',
                style: TextStyle(
                  color: Colors.red,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: theme.fontFamily,
                ),
              ),
            ),
          ],
        ),
        content: SingleChildScrollView(
          child: Text(
            'НАСТОЯТЕЛЬНО ПРОШУ НЕ ЗАПУСКАТЬ ДАННЫЕ АНТИЗАГЛУШКИ В РОССИЙСКИХ СЕРВИСАХ Т.К. УЖЕ ПРОВЕРЕНО ЧТО ЭТИ СЕРВИСЫ БЛОКИРУЮТ РАБОТУ И ПРИВОДЯТ К ПОЛНОЙ НЕРАБОТОСПОСОБНОСТИ.\n\nПри наличии на телефоне российских приложений (VK, Сбер, Госуслуги и др.) — использовать с осторожностью.',
            style: TextStyle(
              color: theme.onBackground,
              fontSize: 14,
              fontFamily: theme.fontFamily,
              height: 1.5,
            ),
          ),
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx),
            style: ElevatedButton.styleFrom(
              backgroundColor: primary,
              foregroundColor: theme.background,
            ),
            child: Text(
              'Понял, продолжить',
              style: TextStyle(fontFamily: theme.fontFamily),
            ),
          ),
        ],
      ),
    );
  }

  void _showWelcomeDialog() {
    final settings = ref.read(settingsProvider);
    final theme = settings.theme;
    final primary = theme.primary;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: theme.background,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: primary.withOpacity(0.5), width: 1.5),
        ),
        title: Text(
          '⚡ INGNET VPN',
          style: TextStyle(
            color: primary,
            fontSize: 20,
            fontWeight: FontWeight.bold,
            fontFamily: theme.fontFamily,
          ),
        ),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Ассаламу Аллейкум братья и сестры.',
                style: TextStyle(
                  color: primary,
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                  fontFamily: theme.fontFamily,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Подписывайтесь на телеграм канал. Ваша поддержка поможет мне в продвижении данного проекта и даст больше мотивации для работы. Заранее благодарен всем.',
                style: TextStyle(
                  color: theme.onBackground,
                  fontSize: 14,
                  fontFamily: theme.fontFamily,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 16),
              GestureDetector(
                onTap: () async {
                  final uri = Uri.parse('https://t.me/INGNET06');
                  if (await canLaunchUrl(uri)) {
                    await launchUrl(uri,
                        mode: LaunchMode.externalApplication);
                  }
                },
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: primary.withOpacity(0.4)),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.telegram, color: primary, size: 22),
                      const SizedBox(width: 8),
                      Text(
                        'https://t.me/INGNET06',
                        style: TextStyle(
                          color: primary,
                          fontSize: 13,
                          fontFamily: theme.fontFamily,
                          decoration: TextDecoration.underline,
                          decorationColor: primary,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(
                  'Отмена',
                  style: TextStyle(
                      color: theme.onBackground.withOpacity(0.6),
                      fontFamily: theme.fontFamily),
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton.icon(
                onPressed: () async {
                  Navigator.pop(ctx);
                  final uri = Uri.parse('https://t.me/INGNET06');
                  if (await canLaunchUrl(uri)) {
                    await launchUrl(uri,
                        mode: LaunchMode.externalApplication);
                  }
                },
                icon: Icon(Icons.telegram, color: theme.background),
                label: Text(
                  'Подписаться',
                  style: TextStyle(
                      fontFamily: theme.fontFamily,
                      color: theme.background),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: primary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _handleConnect() async {
    final settings = ref.read(settingsProvider);
    final vpnState = ref.read(vpnProvider);
    final vpnNotifier = ref.read(vpnProvider.notifier);
    final servers = ref.read(serversProvider);

    if (vpnState.status == VpnStatus.connected ||
        vpnState.status == VpnStatus.connecting) {
      await vpnNotifier.stopVpn();
      return;
    }

    final hasPermission = await vpnNotifier.requestPermission();
    if (!hasPermission) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Разрешение на VPN не предоставлено')),
        );
      }
      return;
    }

    if (!settings.firstConnectDone && !_welcomeShown) {
      _welcomeShown = true;
      await ref.read(settingsProvider.notifier).markFirstConnectDone();
      if (mounted) _showWelcomeDialog();
    }

    if (servers.isEmpty) return;
    final idx = settings.activeServerIndex.clamp(0, servers.length - 1);
    final server = servers[idx];

    await vpnNotifier.startVpn(
      remark: server.name,
      config: server.config,
      notificationMode: settings.notificationMode,
    );
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsProvider);
    final vpnState = ref.watch(vpnProvider);
    final theme = settings.theme;
    final primary = theme.primary;
    final bg = theme.background;
    final isMonochrome = theme.id == 'monochrome';

    Widget mainContent = _buildMainContent(theme, primary, vpnState, settings, isMonochrome);

    // Scanlines overlay
    if (theme.hasScanlines) {
      mainContent = Stack(
        children: [
          mainContent,
          Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(
                painter: ScanlinesPainter(
                  color: primary.withOpacity(0.03),
                  spacing: 3,
                ),
              ),
            ),
          ),
        ],
      );
    }

    return Theme(
      data: theme.toThemeData(),
      child: Scaffold(
        backgroundColor: bg,
        appBar: AppBar(
          backgroundColor: bg,
          foregroundColor: primary,
          title: Text(
            '⚡ INGNET VPN',
            style: TextStyle(
              color: primary,
              fontWeight: FontWeight.bold,
              fontSize: 18,
              fontFamily: theme.fontFamily,
              letterSpacing: 1.2,
            ),
          ),
          actions: [
            IconButton(
              onPressed: () => ThemePicker.show(context),
              icon: Icon(Icons.palette, color: primary),
            ),
          ],
        ),
        drawer: const SidebarDrawer(),
        body: mainContent,
        bottomNavigationBar: _buildWarningBar(primary, theme),
      ),
    );
  }

  Widget _buildMainContent(
    AppTheme theme,
    Color primary,
    VpnState vpnState,
    SettingsState settings,
    bool isMonochrome,
  ) {
    final servers = ref.watch(serversProvider);

    if (isMonochrome) {
      // Monochrome: show settings-like minimal view instead of server list
      return _buildMonochromeLayout(theme, primary, vpnState, settings);
    }

    // Default layout based on button position
    switch (theme.buttonPosition) {
      case 'top':
        return _buildTopLayout(theme, primary, vpnState, settings, servers);
      case 'bottom':
        return _buildBottomLayout(theme, primary, vpnState, settings, servers);
      default:
        return _buildCenterLayout(theme, primary, vpnState, settings, servers);
    }
  }

  Widget _buildCenterLayout(
    AppTheme theme,
    Color primary,
    VpnState vpnState,
    SettingsState settings,
    List servers,
  ) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const SizedBox(height: 20),
          Center(
            child: ConnectButton(
              status: vpnState.status,
              onPressed: _handleConnect,
              theme: theme,
            ),
          ),
          const SizedBox(height: 24),
          TrafficCounter(
            vpnState: vpnState,
            theme: theme,
            onReset: () => ref.read(vpnProvider.notifier).resetTraffic(),
          ),
          const SizedBox(height: 16),
          if (servers.isNotEmpty)
            ServerListWidget(
              theme: theme,
              selectedIndex:
                  settings.activeServerIndex.clamp(0, servers.length - 1),
              onSelect: (i) =>
                  ref.read(settingsProvider.notifier).setActiveServer(i),
            ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildTopLayout(
    AppTheme theme,
    Color primary,
    VpnState vpnState,
    SettingsState settings,
    List servers,
  ) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        children: [
          const SizedBox(height: 8),
          Center(
            child: ConnectButton(
              status: vpnState.status,
              onPressed: _handleConnect,
              theme: theme,
            ).animate().slideY(
                begin: -0.2, end: 0, duration: 400.ms, curve: Curves.easeOut),
          ),
          const SizedBox(height: 16),
          TrafficCounter(
            vpnState: vpnState,
            theme: theme,
            onReset: () => ref.read(vpnProvider.notifier).resetTraffic(),
          ),
          const SizedBox(height: 12),
          if (servers.isNotEmpty)
            ServerListWidget(
              theme: theme,
              selectedIndex:
                  settings.activeServerIndex.clamp(0, servers.length - 1),
              onSelect: (i) =>
                  ref.read(settingsProvider.notifier).setActiveServer(i),
            ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildBottomLayout(
    AppTheme theme,
    Color primary,
    VpnState vpnState,
    SettingsState settings,
    List servers,
  ) {
    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 0),
            child: Column(
              children: [
                TrafficCounter(
                  vpnState: vpnState,
                  theme: theme,
                  onReset: () =>
                      ref.read(vpnProvider.notifier).resetTraffic(),
                ),
                const SizedBox(height: 16),
                if (servers.isNotEmpty)
                  ServerListWidget(
                    theme: theme,
                    selectedIndex:
                        settings.activeServerIndex.clamp(0, servers.length - 1),
                    onSelect: (i) =>
                        ref.read(settingsProvider.notifier).setActiveServer(i),
                  ),
              ],
            ),
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(vertical: 20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [theme.background.withOpacity(0), theme.background],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: Center(
            child: ConnectButton(
              status: vpnState.status,
              onPressed: _handleConnect,
              theme: theme,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMonochromeLayout(
    AppTheme theme,
    Color primary,
    VpnState vpnState,
    SettingsState settings,
  ) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          const SizedBox(height: 20),
          Center(
            child: ConnectButton(
              status: vpnState.status,
              onPressed: _handleConnect,
              theme: theme,
            ),
          ),
          const SizedBox(height: 24),
          TrafficCounter(
            vpnState: vpnState,
            theme: theme,
            onReset: () => ref.read(vpnProvider.notifier).resetTraffic(),
          ),
          const SizedBox(height: 20),
          // Settings summary
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: theme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: primary.withOpacity(0.3)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'КОНФИГУРАЦИЯ',
                  style: TextStyle(
                    color: primary.withOpacity(0.5),
                    fontSize: 11,
                    letterSpacing: 2,
                    fontFamily: theme.fontFamily,
                  ),
                ),
                const SizedBox(height: 12),
                _monoRow('Тема', theme.name, primary, theme),
                _monoRow('Таймаут', '${settings.timeoutMs}мс', primary, theme),
                _monoRow('Авто-режим', settings.autoMode ? 'ВКЛ' : 'ВЫКЛ',
                    primary, theme),
                _monoRow(
                    'URL тест', settings.testUrl, primary, theme),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _monoRow(String key, String value, Color primary, AppTheme theme) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            key,
            style: TextStyle(
              color: primary.withOpacity(0.6),
              fontSize: 13,
              fontFamily: theme.fontFamily,
            ),
          ),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: TextStyle(
                color: primary,
                fontSize: 13,
                fontFamily: theme.fontFamily,
                fontWeight: FontWeight.bold,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWarningBar(Color primary, AppTheme theme) {
    return Container(
      color: Colors.black,
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Center(
        child: Text(
          '⚠️ НЕ ИСПОЛЬЗОВАТЬ В РОССИЙСКИХ СЕРВИСАХ',
          style: TextStyle(
            color: Colors.red,
            fontWeight: FontWeight.bold,
            fontSize: 12,
            fontFamily: theme.fontFamily,
            letterSpacing: 0.5,
          ),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
