import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/vpn_provider.dart';
import '../models/server_model.dart';
import '../models/theme_model.dart';

class ServerListWidget extends ConsumerStatefulWidget {
  final AppTheme theme;
  final int selectedIndex;
  final Function(int) onSelect;

  const ServerListWidget({
    super.key,
    required this.theme,
    required this.selectedIndex,
    required this.onSelect,
  });

  @override
  ConsumerState<ServerListWidget> createState() => _ServerListWidgetState();
}

class _ServerListWidgetState extends ConsumerState<ServerListWidget> {
  bool _expanded = false;

  Color _pingColor(int? ping) {
    if (ping == null) return Colors.grey;
    if (ping < 300) return Colors.green;
    if (ping < 700) return Colors.yellow;
    return Colors.red;
  }

  String _pingLabel(int? ping, bool isTesting) {
    if (isTesting) return '...';
    if (ping == null) return '-';
    return '${ping}ms';
  }

  Future<void> _testAll(List<VpnServer> servers) async {
    final serversNotifier = ref.read(serversProvider.notifier);
    final settingsState = ref.read(settingsProvider);
    final vpnNotifier = ref.read(vpnProvider.notifier);

    for (int i = 0; i < servers.length; i++) {
      await serversNotifier.setServerTesting(i, true);
      final delay = await vpnNotifier.getServerDelay(
        servers[i].config,
        settingsState.testUrl,
      );
      await serversNotifier.updateServerPing(i, delay);
      await serversNotifier.setServerTesting(i, false);
    }
    serversNotifier.sortByPing();
  }

  Future<void> _testOne(List<VpnServer> servers, int index) async {
    final serversNotifier = ref.read(serversProvider.notifier);
    final settingsState = ref.read(settingsProvider);
    final vpnNotifier = ref.read(vpnProvider.notifier);

    await serversNotifier.setServerTesting(index, true);
    final delay = await vpnNotifier.getServerDelay(
      servers[index].config,
      settingsState.testUrl,
    );
    await serversNotifier.updateServerPing(index, delay);
    await serversNotifier.setServerTesting(index, false);
  }

  @override
  Widget build(BuildContext context) {
    final servers = ref.watch(serversProvider);
    final primary = widget.theme.primary;
    final surface = widget.theme.surface;
    final bg = widget.theme.background;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: primary.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          // Header
          InkWell(
            onTap: () => setState(() => _expanded = !_expanded),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  Icon(Icons.dns, color: primary, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Серверы',
                          style: TextStyle(
                            color: primary,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                            fontFamily: widget.theme.fontFamily,
                          ),
                        ),
                        if (servers.isNotEmpty)
                          Text(
                            servers[widget.selectedIndex.clamp(
                                    0, servers.length - 1)]
                                .name,
                            style: TextStyle(
                              color: primary.withOpacity(0.7),
                              fontSize: 12,
                              fontFamily: widget.theme.fontFamily,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                      ],
                    ),
                  ),
                  Icon(
                    _expanded
                        ? Icons.keyboard_arrow_up
                        : Icons.keyboard_arrow_down,
                    color: primary,
                  ),
                ],
              ),
            ),
          ),

          // Expanded list
          if (_expanded) ...[
            Divider(color: primary.withOpacity(0.2), height: 1),
            // Test all button
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: OutlinedButton.icon(
                onPressed: () => _testAll(servers),
                icon: Icon(Icons.speed, color: primary, size: 16),
                label: Text(
                  'Проверить все',
                  style: TextStyle(
                      color: primary, fontFamily: widget.theme.fontFamily),
                ),
                style: OutlinedButton.styleFrom(
                  side: BorderSide(color: primary.withOpacity(0.5)),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                ),
              ),
            ),
            // Server items (lazy)
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: servers.length,
              itemBuilder: (ctx, i) {
                final server = servers[i];
                final isSelected = i == widget.selectedIndex;
                final pingColor = _pingColor(server.ping);
                return InkWell(
                  onTap: () {
                    widget.onSelect(i);
                    setState(() => _expanded = false);
                  },
                  child: Container(
                    color: isSelected
                        ? primary.withOpacity(0.1)
                        : Colors.transparent,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 10),
                    child: Row(
                      children: [
                        Icon(
                          isSelected
                              ? Icons.radio_button_checked
                              : Icons.radio_button_off,
                          color: isSelected ? primary : primary.withOpacity(0.4),
                          size: 18,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            server.name,
                            style: TextStyle(
                              color: isSelected
                                  ? primary
                                  : widget.theme.onSurface,
                              fontSize: 13,
                              fontFamily: widget.theme.fontFamily,
                              fontWeight: isSelected
                                  ? FontWeight.bold
                                  : FontWeight.normal,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        // Ping badge
                        GestureDetector(
                          onTap: () => _testOne(servers, i),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: pingColor.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(10),
                              border:
                                  Border.all(color: pingColor.withOpacity(0.5)),
                            ),
                            child: server.isTesting
                                ? SizedBox(
                                    width: 12,
                                    height: 12,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 1.5,
                                      color: primary,
                                    ),
                                  )
                                : Text(
                                    _pingLabel(server.ping, server.isTesting),
                                    style: TextStyle(
                                      color: pingColor,
                                      fontSize: 11,
                                      fontFamily: widget.theme.fontFamily,
                                    ),
                                  ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ],
      ),
    );
  }
}
