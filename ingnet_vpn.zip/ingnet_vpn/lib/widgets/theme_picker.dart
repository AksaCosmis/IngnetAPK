import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/vpn_provider.dart';
import '../models/theme_model.dart';

class ThemePicker extends ConsumerWidget {
  const ThemePicker({super.key});

  static void show(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => const ThemePicker(),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);
    final currentTheme = settings.theme;

    return DraggableScrollableSheet(
      initialChildSize: 0.6,
      maxChildSize: 0.9,
      minChildSize: 0.4,
      builder: (ctx, controller) {
        return Container(
          decoration: BoxDecoration(
            color: currentTheme.background,
            borderRadius:
                const BorderRadius.vertical(top: Radius.circular(20)),
            border: Border.all(
                color: currentTheme.primary.withOpacity(0.3), width: 1),
          ),
          child: Column(
            children: [
              // Handle
              Container(
                margin: const EdgeInsets.only(top: 12),
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: currentTheme.primary.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  'Выберите тему',
                  style: TextStyle(
                    color: currentTheme.primary,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: currentTheme.fontFamily,
                  ),
                ),
              ),
              Expanded(
                child: GridView.builder(
                  controller: controller,
                  padding: const EdgeInsets.all(16),
                  gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 1.6,
                  ),
                  itemCount: THEMES.length,
                  itemBuilder: (ctx, i) {
                    final t = THEMES[i];
                    final isSelected = t.id == settings.themeId;
                    return GestureDetector(
                      onTap: () {
                        ref.read(settingsProvider.notifier).setTheme(t.id);
                        Navigator.pop(ctx);
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          gradient: LinearGradient(
                            colors: t.gradient,
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          border: Border.all(
                            color: isSelected
                                ? t.primary
                                : t.primary.withOpacity(0.3),
                            width: isSelected ? 2.5 : 1,
                          ),
                          boxShadow: isSelected
                              ? [
                                  BoxShadow(
                                    color: t.primary.withOpacity(0.4),
                                    blurRadius: 12,
                                    spreadRadius: 2,
                                  )
                                ]
                              : null,
                        ),
                        child: Stack(
                          children: [
                            // Badge
                            if (t.badge.isNotEmpty)
                              Positioned(
                                top: 6,
                                right: 6,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: t.primary.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(6),
                                    border: Border.all(
                                        color: t.primary.withOpacity(0.5)),
                                  ),
                                  child: Text(
                                    t.badge,
                                    style: TextStyle(
                                      color: t.primary,
                                      fontSize: 8,
                                      fontFamily: 'monospace',
                                    ),
                                  ),
                                ),
                              ),
                            // Check mark
                            if (isSelected)
                              Positioned(
                                top: 6,
                                left: 6,
                                child: Icon(
                                  Icons.check_circle,
                                  color: t.primary,
                                  size: 16,
                                ),
                              ),
                            Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    width: 28,
                                    height: 28,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: t.primary.withOpacity(0.2),
                                      border: Border.all(
                                          color: t.primary, width: 2),
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    t.name,
                                    style: TextStyle(
                                      color: t.primary,
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: t.fontFamily,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
