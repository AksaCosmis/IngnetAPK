import 'package:flutter/material.dart';

class AppTheme {
  final String id;
  final String name;
  final Color primary;
  final Color background;
  final Color surface;
  final Color onBackground;
  final Color onSurface;
  final String fontFamily;
  final String animationType;
  final String buttonPosition;
  final List<Color> gradient;
  final bool hasScanlines;
  final bool hasGlitch;
  final String badge;

  const AppTheme({
    required this.id,
    required this.name,
    required this.primary,
    required this.background,
    required this.surface,
    required this.onBackground,
    required this.onSurface,
    required this.fontFamily,
    required this.animationType,
    required this.buttonPosition,
    required this.gradient,
    this.hasScanlines = false,
    this.hasGlitch = false,
    this.badge = '',
  });

  ThemeData toThemeData() {
    return ThemeData(
      brightness: background.computeLuminance() < 0.5
          ? Brightness.dark
          : Brightness.light,
      colorScheme: ColorScheme(
        brightness: background.computeLuminance() < 0.5
            ? Brightness.dark
            : Brightness.light,
        primary: primary,
        onPrimary: background,
        secondary: primary.withOpacity(0.7),
        onSecondary: background,
        error: Colors.red,
        onError: Colors.white,
        surface: surface,
        onSurface: onSurface,
      ),
      scaffoldBackgroundColor: background,
      fontFamily: fontFamily,
      appBarTheme: AppBarTheme(
        backgroundColor: background,
        foregroundColor: primary,
        elevation: 0,
      ),
      drawerTheme: DrawerThemeData(
        backgroundColor: surface,
      ),
      textTheme: TextTheme(
        bodyLarge: TextStyle(color: onBackground, fontFamily: fontFamily),
        bodyMedium: TextStyle(color: onBackground, fontFamily: fontFamily),
        bodySmall: TextStyle(color: onBackground.withOpacity(0.7), fontFamily: fontFamily),
        titleLarge: TextStyle(color: primary, fontFamily: fontFamily, fontWeight: FontWeight.bold),
        titleMedium: TextStyle(color: onBackground, fontFamily: fontFamily, fontWeight: FontWeight.w600),
      ),
      useMaterial3: true,
    );
  }
}

const List<AppTheme> THEMES = [
  AppTheme(
    id: 'adrenalin',
    name: 'Adrenalin',
    primary: Color(0xFF00FF41),
    background: Color(0xFF050F05),
    surface: Color(0xFF0A1A0A),
    onBackground: Color(0xFF00FF41),
    onSurface: Color(0xFF00DD33),
    fontFamily: 'monospace',
    animationType: 'pulse',
    buttonPosition: 'center',
    gradient: [Color(0xFF001100), Color(0xFF003300)],
    hasScanlines: true,
    badge: 'HACKER',
  ),
  AppTheme(
    id: 'graffiti',
    name: 'Graffiti',
    primary: Color(0xFFFF0080),
    background: Color(0xFF0D0010),
    surface: Color(0xFF1A0020),
    onBackground: Color(0xFFFF0080),
    onSurface: Color(0xFFFF66AA),
    fontFamily: 'sans-serif-condensed',
    animationType: 'shake',
    buttonPosition: 'top',
    gradient: [Color(0xFF200010), Color(0xFF400040)],
    hasGlitch: true,
    badge: 'STREET',
  ),
  AppTheme(
    id: 'classic',
    name: 'Classic',
    primary: Color(0xFF2196F3),
    background: Color(0xFF121212),
    surface: Color(0xFF1E1E1E),
    onBackground: Color(0xFFE0E0E0),
    onSurface: Color(0xFFBDBDBD),
    fontFamily: 'sans-serif',
    animationType: 'pulse',
    buttonPosition: 'center',
    gradient: [Color(0xFF1565C0), Color(0xFF42A5F5)],
    badge: 'DEFAULT',
  ),
  AppTheme(
    id: 'monochrome',
    name: 'Monochrome',
    primary: Color(0xFFFFFFFF),
    background: Color(0xFF000000),
    surface: Color(0xFF111111),
    onBackground: Color(0xFFFFFFFF),
    onSurface: Color(0xFFCCCCCC),
    fontFamily: 'monospace',
    animationType: 'none',
    buttonPosition: 'center',
    gradient: [Color(0xFF222222), Color(0xFF444444)],
    badge: 'MINIMAL',
  ),
  AppTheme(
    id: 'cyberpunk',
    name: 'Cyberpunk',
    primary: Color(0xFFFF00FF),
    background: Color(0xFF0A0010),
    surface: Color(0xFF150020),
    onBackground: Color(0xFFFF00FF),
    onSurface: Color(0xFFCC00CC),
    fontFamily: 'monospace',
    animationType: 'glitch',
    buttonPosition: 'center',
    gradient: [Color(0xFF1A001A), Color(0xFF330033)],
    hasScanlines: true,
    hasGlitch: true,
    badge: 'CYBER',
  ),
  AppTheme(
    id: 'matrix',
    name: 'Matrix',
    primary: Color(0xFF00FF00),
    background: Color(0xFF000000),
    surface: Color(0xFF001100),
    onBackground: Color(0xFF00FF00),
    onSurface: Color(0xFF00CC00),
    fontFamily: 'monospace',
    animationType: 'rain',
    buttonPosition: 'center',
    gradient: [Color(0xFF000500), Color(0xFF001500)],
    hasScanlines: true,
    badge: 'MATRIX',
  ),
  AppTheme(
    id: 'fire',
    name: 'Fire',
    primary: Color(0xFFFF4500),
    background: Color(0xFF0F0500),
    surface: Color(0xFF1A0800),
    onBackground: Color(0xFFFF8C00),
    onSurface: Color(0xFFFF6600),
    fontFamily: 'sans-serif-condensed',
    animationType: 'pulse',
    buttonPosition: 'bottom',
    gradient: [Color(0xFFFF4500), Color(0xFFFF8C00)],
    badge: 'BLAZING',
  ),
  AppTheme(
    id: 'ocean',
    name: 'Ocean',
    primary: Color(0xFF00BFFF),
    background: Color(0xFF000D1A),
    surface: Color(0xFF001A33),
    onBackground: Color(0xFF00BFFF),
    onSurface: Color(0xFF0099CC),
    fontFamily: 'sans-serif',
    animationType: 'wave',
    buttonPosition: 'center',
    gradient: [Color(0xFF001133), Color(0xFF0033AA)],
    badge: 'DEEP',
  ),
  AppTheme(
    id: 'gold',
    name: 'Gold',
    primary: Color(0xFFFFD700),
    background: Color(0xFF0A0800),
    surface: Color(0xFF1A1400),
    onBackground: Color(0xFFFFD700),
    onSurface: Color(0xFFCCAA00),
    fontFamily: 'serif',
    animationType: 'glow',
    buttonPosition: 'center',
    gradient: [Color(0xFFFFD700), Color(0xFFFFA500)],
    badge: 'PREMIUM',
  ),
  AppTheme(
    id: 'dark_neon',
    name: 'Dark Neon',
    primary: Color(0xFFFF1493),
    background: Color(0xFF050008),
    surface: Color(0xFF0D0015),
    onBackground: Color(0xFFFF1493),
    onSurface: Color(0xFFCC0070),
    fontFamily: 'monospace',
    animationType: 'pulse',
    buttonPosition: 'center',
    gradient: [Color(0xFF1A0025), Color(0xFF33004A)],
    hasGlitch: true,
    badge: 'NEON',
  ),
];
