class VpnServer {
  final String name;
  final String config;
  int? ping;
  bool isTesting;

  VpnServer({
    required this.name,
    required this.config,
    this.ping,
    this.isTesting = false,
  });

  factory VpnServer.fromJson(Map<String, dynamic> json) {
    return VpnServer(
      name: json['name'] as String,
      config: json['config'] as String,
      ping: json['ping'] as int?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'config': config,
      'ping': ping,
    };
  }

  VpnServer copyWith({
    String? name,
    String? config,
    int? ping,
    bool? isTesting,
  }) {
    return VpnServer(
      name: name ?? this.name,
      config: config ?? this.config,
      ping: ping ?? this.ping,
      isTesting: isTesting ?? this.isTesting,
    );
  }
}

const List<Map<String, String>> FALLBACK_SERVERS = [
  {
    'name': 'AUTO_SERVER',
    'config':
        'vless://auto@auto.ingnet.vpn:443?encryption=none&security=tls&type=ws&path=%2F#AUTO_SERVER',
  },
  {
    'name': 'NL-Turbo #1',
    'config':
        'vless://00000000-0000-0000-0000-000000000001@nl1.ingnet.vpn:443?encryption=none&security=tls&type=ws&path=%2Fvpn#NL-Turbo%20%231',
  },
  {
    'name': 'NL-Premium #2',
    'config':
        'vless://00000000-0000-0000-0000-000000000002@nl2.ingnet.vpn:443?encryption=none&security=tls&type=ws&path=%2Fvpn#NL-Premium%20%232',
  },
  {
    'name': 'DE-Secure #1',
    'config':
        'vless://00000000-0000-0000-0000-000000000003@de1.ingnet.vpn:443?encryption=none&security=tls&type=ws&path=%2Fvpn#DE-Secure%20%231',
  },
  {
    'name': 'UK-Fast #1',
    'config':
        'vless://00000000-0000-0000-0000-000000000004@uk1.ingnet.vpn:443?encryption=none&security=tls&type=ws&path=%2Fvpn#UK-Fast%20%231',
  },
];
